Manhattan Distance
====================================
Definition: The distance between two points measured along axes at right angles.
====================================

This library allows you to calculate the Manhattan Distance between two points using their coordinates.

Usage: 
from manhattandistance import utils
    utils.mandist(lat_from, lon_from, lat_to, lon_to) 
lat = integer or float

